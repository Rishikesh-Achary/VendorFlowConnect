import { useState, useEffect, useRef } from "react";

// ─── Palette & fonts injected via style tag ───────────────────────────────
const GlobalStyle = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500&family=DM+Mono&display=swap');

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --bg:        #0D1220;
      --bg-2:      #0D1220;
      --surface:   #1A2035;
      --card:      #1A2035;
      --card-2:    #1A2035;
      --border:    #252D4A;
      --border-strong: #2F385A;
      --accent:    #2DFFA0;
      --accent-2:  #2DFFA0;
      --accent-glow: 0 0 0 1px rgba(45,255,160,.25), 0 8px 30px -8px rgba(45,255,160,.35);
      --danger:    #FF6B6B;
      --info:      #6B8FFF;
      --gold:      #FFB547;
      --text:      #E2E6F0;
      --text-dim:  #C2C8DC;
      --muted:     #6B7299;
      --radius:    14px;
      --radius-sm: 10px;
      --radius-lg: 20px;
      --font-head: 'Syne', sans-serif;
      --font-body: 'DM Sans', sans-serif;
      --font-mono: 'DM Mono', ui-monospace, monospace;
      --shadow-sm: 0 1px 2px rgba(0,0,0,.4);
      --shadow-md: 0 8px 24px -8px rgba(0,0,0,.5);
      --shadow-lg: 0 24px 60px -20px rgba(0,0,0,.6);
      /* legacy aliases */
      --accent2: var(--danger);
      --accent3: var(--info);
    }

    html, body { background: var(--bg); }
    body {
      color: var(--text);
      font-family: var(--font-body);
      font-size: 14px;
      -webkit-font-smoothing: antialiased;
      background-image:
        radial-gradient(1100px 600px at 85% -10%, rgba(45,255,160,.04), transparent 60%),
        radial-gradient(900px 500px at -10% 110%, rgba(107,143,255,.05), transparent 60%);
      background-attachment: fixed;
    }

    /* Apply DM Mono to any inline monospace usage (vendor IDs, GST, etc.) */
    [style*="monospace"] { font-family: var(--font-mono) !important; letter-spacing: 0; }
    .mono { font-family: var(--font-mono); }

    ::-webkit-scrollbar { width: 8px; height: 8px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: #252D4A; border-radius: 99px; }
    ::-webkit-scrollbar-thumb:hover { background: #2F385A; }

    .app { display: flex; min-height: 100vh; }

    /* Sidebar */
    .sidebar {
      width: 244px; min-width: 244px;
      background: linear-gradient(180deg, #0D1220 0%, #111827 100%);
      backdrop-filter: blur(20px);
      border-right: 1px solid var(--border);
      display: flex; flex-direction: column;
      padding: 22px 0; position: sticky; top: 0; height: 100vh; overflow-y: auto;
    }
    .logo {
      padding: 0 22px 28px; font-family: var(--font-head); font-size: 22px;
      font-weight: 800; letter-spacing: -0.5px; color: var(--text);
    }
    .logo span {
      color: var(--accent);
    }
    .logo sub { font-size: 9.5px; color: var(--muted); font-weight: 500; display: block; letter-spacing: 1.6px; text-transform: uppercase; margin-top: 4px; }
    .nav-section { font-size: 10px; letter-spacing: 1.6px; color: var(--muted); text-transform: uppercase; padding: 14px 22px 6px; font-weight: 600; }
    .nav-item {
      display: flex; align-items: center; gap: 12px;
      margin: 1px 12px; padding: 9px 12px;
      cursor: pointer; color: var(--text-dim); transition: all .18s ease;
      font-size: 13.5px; border-radius: 8px;
      position: relative;
      border-left: 2px solid transparent;
    }
    .nav-item:hover { color: var(--text); background: rgba(45,255,160,0.03); }
    .nav-item.active {
      color: var(--accent); font-weight: 500;
      background: rgba(45,255,160,0.07);
      border-left: 2px solid var(--accent);
      border-radius: 0 8px 8px 0;
    }
    .nav-item.active .icon { filter: none; }
    .nav-item .icon { font-size: 15px; width: 18px; text-align: center; }
    .nav-badge {
      margin-left: auto; background: var(--danger); color: #fff; font-size: 10px;
      font-weight: 700; padding: 2px 7px; border-radius: 99px; line-height: 1.4;
    }
    .nav-item.active .nav-badge { background: var(--danger); color: #fff; }
    .sidebar-footer { margin-top: auto; padding: 16px 14px 0; border-top: 1px solid var(--border); }
    .user-chip {
      display: flex; align-items: center; gap: 10px; padding: 10px 12px;
      background: var(--surface); border: 1px solid var(--border);
      border-radius: 12px; cursor: pointer; transition: border-color .15s;
    }
    .user-chip:hover { border-color: var(--accent); }
    .avatar {
      width: 32px; height: 32px; border-radius: 50%;
      background: var(--accent);
      display: flex; align-items: center; justify-content: center;
      font-size: 12px; font-weight: 700; color: var(--bg); flex-shrink: 0;
      font-family: var(--font-head);
    }
    .user-info { font-size: 12px; line-height: 1.3; }
    .user-info b { display: block; color: var(--text); font-size: 13px; font-weight: 600; }
    .user-role { color: var(--muted); font-size: 11px; }

    /* Main */
    .main { flex: 1; display: flex; flex-direction: column; min-width: 0; }
    .topbar {
      padding: 18px 36px;
      background: rgba(26,32,53,.72);
      backdrop-filter: blur(16px);
      border-bottom: 1px solid var(--border);
      display: flex; align-items: center; justify-content: space-between;
      position: sticky; top: 0; z-index: 10;
    }
    .page-title { font-family: var(--font-head); font-size: 24px; font-weight: 800; letter-spacing: -0.5px; color: var(--text); }
    .topbar-right { display: flex; align-items: center; gap: 10px; }
    .topbar-actions { display: flex; gap: 8px; }
    .content { padding: 32px 36px; flex: 1; }

    /* Buttons */
    .btn {
      display: inline-flex; align-items: center; gap: 7px; padding: 9px 16px;
      border-radius: 8px; font-family: var(--font-body); font-size: 13px; font-weight: 500;
      cursor: pointer; border: 1px solid transparent; transition: all .18s ease;
      white-space: nowrap;
    }
    .btn-primary {
      background: var(--accent);
      color: var(--bg); font-family: var(--font-head); font-weight: 700;
      letter-spacing: -0.2px;
      box-shadow: 0 4px 14px -4px rgba(45,255,160,.35);
    }
    .btn-primary:hover { transform: scale(1.02); filter: brightness(1.08); box-shadow: 0 8px 22px -6px rgba(45,255,160,.55); }
    .btn-secondary { background: var(--surface); color: var(--text); border-color: var(--border-strong); }
    .btn-secondary:hover { background: #222a45; border-color: var(--accent); color: var(--accent); }
    .btn-danger { background: rgba(255,107,107,.12); color: var(--danger); border-color: rgba(255,107,107,.3); }
    .btn-danger:hover { background: rgba(255,107,107,.2); }
    .btn-sm { padding: 6px 12px; font-size: 12px; border-radius: 6px; }
    .btn-ghost { background: transparent; color: var(--text-dim); border-color: var(--border); }
    .btn-ghost:hover { color: var(--text); border-color: var(--border-strong); background: var(--surface); }

    /* Cards */
    .card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 22px;
      box-shadow: var(--shadow-md);
    }
    .card-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 18px; }
    .stat-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-left: 1px solid var(--accent);
      border-radius: var(--radius);
      padding: 22px; position: relative; overflow: hidden;
      transition: transform .2s ease, border-color .2s ease;
    }
    .stat-card:hover { transform: translateY(-2px); }
    .stat-card.green { border-left-color: var(--accent); }
    .stat-card.red { border-left-color: var(--danger); }
    .stat-card.blue { border-left-color: var(--info); }
    .stat-card.gold { border-left-color: var(--gold); }
    .stat-icon {
      font-size: 18px; margin-bottom: 14px;
      width: 38px; height: 38px; display: inline-flex;
      align-items: center; justify-content: center;
      background: var(--bg);
      border: 1px solid var(--border);
      border-radius: 10px;
    }
    .stat-label { color: var(--muted); font-size: 11px; text-transform: uppercase; letter-spacing: 1px; font-weight: 600; }
    .stat-value { font-family: var(--font-head); font-size: 32px; font-weight: 800; margin: 6px 0; letter-spacing: -0.5px; color: var(--accent); }
    .stat-delta { font-size: 12px; font-weight: 500; }
    .stat-delta.up { color: var(--accent); }
    .stat-delta.down { color: var(--danger); }

    /* Table */
    .table-wrap { overflow-x: auto; margin: -4px; padding: 4px; }
    table { width: 100%; border-collapse: collapse; }
    thead th {
      padding: 12px 16px; text-align: left;
      font-size: 10.5px; text-transform: uppercase; letter-spacing: 1px;
      color: var(--muted); border-bottom: 1px solid var(--border);
      font-weight: 600; white-space: nowrap;
    }
    tbody td { padding: 14px 16px; border-bottom: 1px solid var(--border); font-size: 13px; vertical-align: middle; color: var(--text-dim); }
    tbody tr { transition: background .15s ease; border-left: 2px solid transparent; }
    tbody tr:hover { border-left: 2px solid rgba(45,255,160,.3); }
    tbody tr:hover td { background: rgba(45,255,160,.04); color: var(--text); }
    tbody tr:last-child td { border-bottom: none; }

    /* Badges */
    .badge {
      display: inline-flex; align-items: center; gap: 5px;
      padding: 4px 10px; border-radius: 99px;
      font-size: 11px; font-weight: 600; letter-spacing: .2px;
      border: 1px solid transparent;
    }
    .badge::before { content:''; width:5px; height:5px; border-radius:50%; background: currentColor; }
    .badge-green { background: rgba(45,255,160,.12); color: var(--accent); border-color: rgba(45,255,160,.25); }
    .badge-red { background: rgba(255,107,107,.12); color: var(--danger); border-color: rgba(255,107,107,.25); }
    .badge-blue { background: rgba(107,143,255,.12); color: var(--info); border-color: rgba(107,143,255,.25); }
    .badge-gold { background: rgba(255,181,71,.12); color: var(--gold); border-color: rgba(255,181,71,.25); }
    .badge-gray { background: rgba(107,114,153,.14); color: var(--muted); border-color: rgba(107,114,153,.25); }

    /* Forms */
    .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .form-group { display: flex; flex-direction: column; gap: 6px; }
    .form-group.full { grid-column: 1/-1; }
    label { font-size: 11.5px; color: var(--muted); font-weight: 600; letter-spacing: .6px; text-transform: uppercase; }
    input, select, textarea {
      background: var(--bg); border: 1px solid var(--border-strong); color: var(--text);
      border-radius: 10px; padding: 11px 14px; font-family: var(--font-body); font-size: 13.5px;
      transition: all .15s; width: 100%;
    }
    input::placeholder, textarea::placeholder { color: var(--muted); }
    input:focus, select:focus, textarea:focus {
      outline: none; border-color: var(--accent);
      box-shadow: 0 0 0 3px rgba(45,255,160,.14);
      background: var(--bg);
    }
    textarea { resize: vertical; min-height: 88px; }
    select option { background: var(--card); color: var(--text); }

    /* Modal */
    .modal-overlay {
      position: fixed; inset: 0;
      background: rgba(4,6,12,.6); backdrop-filter: blur(8px);
      z-index: 100; display: flex; align-items: center; justify-content: center;
      padding: 20px; animation: fadeIn .18s ease;
    }
    .modal {
      background: var(--surface);
      border: 1px solid var(--border-strong); border-top: 1px solid rgba(45,255,160,0.2);
      border-radius: 18px;
      width: 100%; max-width: 600px; max-height: 90vh; overflow-y: auto;
      box-shadow: 0 24px 80px rgba(0,0,0,0.5);
      animation: slideUp .22s ease;
    }
    .modal-header { padding: 22px 26px; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; }
    .modal-title { font-family: var(--font-head); font-size: 20px; font-weight: 800; letter-spacing: -0.4px; color: var(--text); }
    .modal-body { padding: 26px; }
    .modal-footer { padding: 18px 26px; border-top: 1px solid var(--border); display: flex; gap: 10px; justify-content: flex-end; }
    .close-btn { background: var(--bg); border: 1px solid var(--border); color: var(--muted); cursor: pointer; font-size: 16px; line-height: 1; width: 30px; height: 30px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; transition: all .15s; }
    .close-btn:hover { color: var(--text); border-color: var(--border-strong); }

    /* Search */
    .search-box { position: relative; }
    .search-box input { padding-left: 38px; width: 260px; }
    .search-box::before { content: '🔍'; position: absolute; left: 12px; top: 50%; transform: translateY(-50%); font-size: 12px; pointer-events: none; opacity: .6; }

    /* Section header */
    .section-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 22px; flex-wrap: wrap; gap: 12px; }
    .section-title { font-family: var(--font-head); font-size: 18px; font-weight: 800; letter-spacing: -0.4px; color: var(--text); }

    /* Tabs */
    .tabs {
      display: inline-flex; gap: 2px;
      background: var(--surface); border: 1px solid var(--border);
      border-radius: 12px; padding: 4px; margin-bottom: 22px;
    }
    .tab { padding: 8px 18px; border-radius: 8px; font-size: 13px; cursor: pointer; color: var(--muted); transition: all .18s ease; font-weight: 500; }
    .tab:hover { color: var(--text); }
    .tab.active { background: var(--accent); color: var(--bg); font-family: var(--font-head); font-weight: 700; }

    /* Timeline */
    .timeline { display: flex; flex-direction: column; gap: 0; }
    .tl-item { display: flex; gap: 14px; position: relative; padding-bottom: 22px; }
    .tl-item:last-child { padding-bottom: 0; }
    .tl-dot {
      width: 10px; height: 10px; border-radius: 50%; background: var(--accent);
      flex-shrink: 0; margin-top: 5px; position: relative; z-index: 1;
      box-shadow: 0 0 0 4px rgba(45,255,160,.14);
    }
    .tl-item::before { content:''; position:absolute; left:4px; top:18px; bottom:4px; width:2px; background: var(--border-strong); }
    .tl-item:last-child::before { display: none; }
    .tl-content { flex: 1; }
    .tl-title { font-size: 13px; font-weight: 500; color: var(--text); }
    .tl-time { font-size: 11px; color: var(--muted); margin-top: 2px; }
    .tl-meta { font-size: 12px; color: var(--muted); margin-top: 3px; }

    /* Comparison table */
    .compare-table th { background: var(--bg); }
    .compare-table .highlight-col td { background: rgba(45,255,160,.06); }
    .best-price { color: var(--accent); font-weight: 700; }

    /* Progress bar */
    .progress-bar { background: var(--bg); border-radius: 99px; height: 6px; overflow: hidden; border: 1px solid var(--border); }
    .progress-fill { height: 100%; border-radius: 99px; background: var(--accent); transition: width .4s; }

    /* Chart bar */
    .chart-bars { display: flex; align-items: flex-end; gap: 10px; height: 140px; padding-top: 10px; }
    .chart-bar-wrap { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 4px; height: 100%; justify-content: flex-end; }
    .chart-bar {
      width: 100%; border-radius: 6px 6px 0 0;
      background: var(--info);
      opacity: .9; transition: all .3s; min-height: 4px;
      cursor: pointer;
    }
    .chart-bar:hover { opacity: 1; filter: brightness(1.2); }
    .chart-label { font-size: 10px; color: var(--muted); }

    /* Approval flow */
    .flow-step { display: flex; align-items: center; gap: 12px; padding: 14px 18px; background: var(--bg); border-radius: var(--radius); border: 1px solid var(--border); }
    .flow-connector { width: 2px; height: 22px; background: var(--border-strong); margin-left: 24px; }

    /* Login */
    .login-wrap {
      min-height: 100vh; display: flex; align-items: center; justify-content: center;
      padding: 20px; position: relative; overflow: hidden;
      background:
        radial-gradient(800px 500px at 20% 20%, rgba(45,255,160,.10), transparent 60%),
        radial-gradient(700px 500px at 80% 80%, rgba(107,143,255,.10), transparent 60%),
        var(--bg);
    }
    .login-card {
      background: var(--surface);
      backdrop-filter: blur(24px);
      border: 1px solid var(--border-strong); border-radius: 24px;
      padding: 44px; width: 100%; max-width: 420px;
      box-shadow: 0 24px 80px rgba(0,0,0,0.5);
    }
    .login-logo { font-family: var(--font-head); font-size: 32px; font-weight: 800; margin-bottom: 8px; letter-spacing: -0.5px; color: var(--text); }
    .login-logo span { color: var(--accent); }
    .login-sub { color: var(--muted); font-size: 13px; margin-bottom: 32px; }

    /* Notification dot */
    .notif-btn {
      position: relative; background: var(--surface);
      border: 1px solid var(--border-strong); color: var(--text-dim);
      border-radius: 10px; padding: 8px 11px; cursor: pointer; font-size: 15px; line-height: 1;
      transition: all .15s;
    }
    .notif-btn:hover { color: var(--text); border-color: var(--accent); }
    .notif-dot { position: absolute; top: 5px; right: 5px; width: 8px; height: 8px; background: var(--danger); border-radius: 50%; border: 2px solid var(--surface); }

    /* Toast */
    .toast {
      position: fixed; bottom: 28px; right: 28px;
      background: var(--surface);
      border: 1px solid var(--accent);
      color: var(--text); padding: 14px 22px; border-radius: 12px;
      font-size: 13px; font-weight: 500; z-index: 999;
      box-shadow: var(--shadow-lg), 0 0 0 4px rgba(45,255,160,.10);
      animation: slideUp .25s ease;
    }

    @keyframes fadeIn { from { opacity:0 } to { opacity:1 } }
    @keyframes slideUp { from { transform:translateY(16px);opacity:0 } to { transform:translateY(0);opacity:1 } }

    /* Invoice preview — printed document look */
    .invoice-preview {
      background: #FFFFFF; color: #1A1A1A; padding: 40px;
      border-radius: 8px; font-family: var(--font-body);
      box-shadow: 0 20px 60px rgba(0,0,0,0.4);
    }
    .invoice-preview .inv-logo { font-family: var(--font-head); font-weight: 800; font-size: 26px; color: #2DFFA0; letter-spacing: -0.5px; }
    .invoice-preview h1, .invoice-preview h2, .invoice-preview h3 { font-family: var(--font-head); color: #0D1220; }
    .invoice-preview table { width: 100%; border-collapse: collapse; margin: 20px 0; }
    .invoice-preview th, .invoice-preview td { padding: 10px 12px; text-align: left; border-bottom: 1px solid #E5E7EB; font-size: 13px; color: #1A1A1A; }
    .invoice-preview thead th { background: #F9FAFB; color: #6B7280; text-transform: uppercase; font-size: 10.5px; letter-spacing: 1px; border-bottom: 1px solid #D1D5DB; }
    .invoice-preview .inv-mono { font-family: var(--font-mono); }
    .invoice-preview .inv-footer { margin-top: 28px; padding-top: 16px; border-top: 1px solid #E5E7EB; color: #6B7280; font-size: 11px; text-align: center; }

    .gap-2 { gap: 8px; }
    .gap-3 { gap: 12px; }
    .flex { display: flex; }
    .flex-col { flex-direction: column; }
    .items-center { align-items: center; }
    .justify-between { justify-content: space-between; }
    .mt-1 { margin-top: 4px; }
    .mt-2 { margin-top: 8px; }
    .mt-3 { margin-top: 12px; }
    .mt-4 { margin-top: 16px; }
    .mb-1 { margin-bottom: 4px; }
    .mb-2 { margin-bottom: 8px; }
    .mb-4 { margin-bottom: 16px; }
    .text-muted { color: var(--muted); }
    .text-accent { color: var(--accent); }
    .text-sm { font-size: 12px; }
    .font-head { font-family: var(--font-head); font-weight: 800; letter-spacing: -0.3px; }
    .w-full { width: 100%; }
    .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; }
  `}</style>
);

// ─── Seed Data ─────────────────────────────────────────────────────────────
const INIT = {
  vendors: [
    { id: 'V001', name: 'TechSupply Co.', category: 'IT Hardware', email: 'sales@techsupply.com', phone: '+91-9876543210', gst: '27AABCT1332L1ZK', status: 'Active', rating: 4.5 },
    { id: 'V002', name: 'OfficeWorld Ltd.', category: 'Office Supplies', email: 'orders@officeworld.in', phone: '+91-9123456789', gst: '29AACCM7736H1ZA', status: 'Active', rating: 4.0 },
    { id: 'V003', name: 'BuildRight Inc.', category: 'Construction', email: 'bids@buildright.com', phone: '+91-9988776655', gst: '07AADCB1234M1ZP', status: 'Inactive', rating: 3.8 },
    { id: 'V004', name: 'SwiftLogistics', category: 'Logistics', email: 'rfq@swift.co.in', phone: '+91-9871234560', gst: '19AACCS4563K1ZQ', status: 'Active', rating: 4.2 },
  ],
  rfqs: [
    { id: 'RFQ-001', title: 'Laptop Procurement Q3', product: 'Laptops (15" Dell XPS)', qty: 50, deadline: '2026-06-20', vendorIds: ['V001', 'V002'], status: 'Open', createdAt: '2026-06-01' },
    { id: 'RFQ-002', title: 'Office Furniture Refresh', product: 'Ergonomic Chairs + Desks', qty: 30, deadline: '2026-06-25', vendorIds: ['V002', 'V003'], status: 'Comparison', createdAt: '2026-05-28' },
    { id: 'RFQ-003', title: 'Network Equipment Upgrade', product: 'Cisco Switches 48-port', qty: 10, deadline: '2026-07-05', vendorIds: ['V001', 'V004'], status: 'Approved', createdAt: '2026-05-20' },
  ],
  quotations: [
    { id: 'Q001', rfqId: 'RFQ-001', vendorId: 'V001', unitPrice: 82000, delivery: '10 days', notes: 'Includes 1yr onsite warranty', status: 'Submitted' },
    { id: 'Q002', rfqId: 'RFQ-001', vendorId: 'V002', unitPrice: 79500, delivery: '14 days', notes: 'Bulk discount applied', status: 'Submitted' },
    { id: 'Q003', rfqId: 'RFQ-002', vendorId: 'V002', unitPrice: 12500, delivery: '7 days', notes: 'Assembly included', status: 'Submitted' },
    { id: 'Q004', rfqId: 'RFQ-002', vendorId: 'V003', unitPrice: 11800, delivery: '12 days', notes: 'Standard finish', status: 'Submitted' },
    { id: 'Q005', rfqId: 'RFQ-003', vendorId: 'V001', unitPrice: 45000, delivery: '5 days', notes: 'Configured & tested', status: 'Approved' },
    { id: 'Q006', rfqId: 'RFQ-003', vendorId: 'V004', unitPrice: 47200, delivery: '8 days', notes: 'With installation support', status: 'Submitted' },
  ],
  orders: [
    { id: 'PO-2026-001', rfqId: 'RFQ-003', quotationId: 'Q005', vendorId: 'V001', title: 'Network Equipment Upgrade', qty: 10, unitPrice: 45000, tax: 18, status: 'Invoiced', createdAt: '2026-05-25', invoiceId: 'INV-2026-001' },
  ],
  invoices: [
    { id: 'INV-2026-001', poId: 'PO-2026-001', vendorId: 'V001', title: 'Network Equipment Upgrade', qty: 10, unitPrice: 45000, tax: 18, status: 'Sent', createdAt: '2026-05-26' },
  ],
  approvals: [
    { id: 'APR-001', rfqId: 'RFQ-003', quotationId: 'Q005', requestedBy: 'Priya S.', status: 'Approved', remarks: 'Best value, proceed.', createdAt: '2026-05-22', resolvedAt: '2026-05-23' },
    { id: 'APR-002', rfqId: 'RFQ-002', quotationId: 'Q004', requestedBy: 'Rahul M.', status: 'Pending', remarks: '', createdAt: '2026-06-05', resolvedAt: null },
  ],
  logs: [
    { id: 1, type: 'rfq', text: 'RFQ-001 created for Laptop Procurement Q3', time: '2026-06-01 09:10', user: 'Priya S.' },
    { id: 2, type: 'quotation', text: 'Quotation submitted by TechSupply Co. for RFQ-001', time: '2026-06-02 11:30', user: 'Vendor' },
    { id: 3, type: 'quotation', text: 'Quotation submitted by OfficeWorld Ltd. for RFQ-001', time: '2026-06-03 14:05', user: 'Vendor' },
    { id: 4, type: 'approval', text: 'Approval APR-001 granted for PO-2026-001', time: '2026-05-23 16:22', user: 'Mgr. Rao' },
    { id: 5, type: 'invoice', text: 'Invoice INV-2026-001 sent to TechSupply Co.', time: '2026-05-26 10:00', user: 'System' },
    { id: 6, type: 'rfq', text: 'RFQ-002 moved to Comparison stage', time: '2026-06-05 09:45', user: 'Priya S.' },
  ],
};

const fmtCurrency = (n) => '₹' + Number(n).toLocaleString('en-IN');
const fmtDate = (d) => new Date(d).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' });
const genId = (prefix, list) => `${prefix}-${String(list.length + 1).padStart(3,'0')}`;

// ─── Toast ─────────────────────────────────────────────────────────────────
function Toast({ msg, onDone }) {
  useEffect(() => { const t = setTimeout(onDone, 2200); return () => clearTimeout(t); }, []);
  return <div className="toast">✅ {msg}</div>;
}

// ─── Login Screen ──────────────────────────────────────────────────────────
function LoginScreen({ onLogin }) {
  const [form, setForm] = useState({ email: 'admin@vendorbridge.com', password: 'admin123', role: 'Admin' });
  return (
    <div className="login-wrap">
      <div className="login-card">
        <div className="login-logo">Vendor<span>Bridge</span></div>
        <div className="login-sub">Procurement & Vendor Management ERP</div>
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <div className="form-group">
            <label>Email Address</label>
            <input value={form.email} onChange={e=>setForm({...form, email:e.target.value})} />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input type="password" value={form.password} onChange={e=>setForm({...form, password:e.target.value})} />
          </div>
          <div className="form-group">
            <label>Login As</label>
            <select value={form.role} onChange={e=>setForm({...form, role:e.target.value})}>
              <option>Admin</option>
              <option>Procurement Officer</option>
              <option>Manager / Approver</option>
              <option>Vendor</option>
            </select>
          </div>
          <button className="btn btn-primary w-full" style={{marginTop:8, justifyContent:'center'}} onClick={()=>onLogin(form)}>
            Sign In →
          </button>
          <div style={{textAlign:'center', fontSize:12, color:'var(--muted)'}}>
            <span style={{cursor:'pointer', color:'var(--accent3)'}}>Forgot password?</span> · <span style={{cursor:'pointer', color:'var(--accent3)'}}>Create account</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Dashboard ─────────────────────────────────────────────────────────────
function Dashboard({ data }) {
  const totalSpend = data.invoices.reduce((s,i)=>{
    const sub = i.qty * i.unitPrice;
    return s + sub + sub*i.tax/100;
  }, 0);
  const months = ['Jan','Feb','Mar','Apr','May','Jun'];
  const spends = [420000, 680000, 510000, 790000, 630000, totalSpend];
  const maxSpend = Math.max(...spends);

  return (
    <div style={{display:'flex', flexDirection:'column', gap:24}}>
      <div className="card-grid">
        {[
          { label:'Active Vendors', value: data.vendors.filter(v=>v.status==='Active').length, icon:'🏢', cls:'green', delta:'+2 this month', up:true },
          { label:'Open RFQs', value: data.rfqs.filter(r=>r.status==='Open').length, icon:'📋', cls:'blue', delta:'3 deadlines soon', up:false },
          { label:'Pending Approvals', value: data.approvals.filter(a=>a.status==='Pending').length, icon:'⏳', cls:'gold', delta:'Needs attention', up:false },
          { label:'Total Spend (YTD)', value: fmtCurrency(totalSpend), icon:'💰', cls:'red', delta:'+12% vs last qtr', up:true },
        ].map(s=>(
          <div key={s.label} className={`stat-card ${s.cls}`}>
            <div className="stat-icon">{s.icon}</div>
            <div className="stat-label">{s.label}</div>
            <div className="stat-value" style={{fontSize: typeof s.value==='string'?'20px':'30px'}}>{s.value}</div>
            <div className={`stat-delta ${s.up?'up':'down'}`}>{s.delta}</div>
          </div>
        ))}
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="section-header mb-2">
            <div className="section-title">Monthly Procurement Spend</div>
          </div>
          <div className="chart-bars">
            {months.map((m,i)=>(
              <div key={m} className="chart-bar-wrap">
                <div className="chart-bar" style={{height:`${(spends[i]/maxSpend)*100}%`, background: i===5?'var(--accent)':'var(--accent3)'}} title={fmtCurrency(spends[i])} />
                <div className="chart-label">{m}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="section-title mb-4">Recent Activity</div>
          <div className="timeline">
            {data.logs.slice(-5).reverse().map(l=>(
              <div key={l.id} className="tl-item">
                <div className="tl-dot" style={{background: l.type==='rfq'?'var(--accent3)': l.type==='approval'?'var(--gold)': l.type==='invoice'?'var(--accent2)':'var(--accent)'}} />
                <div className="tl-content">
                  <div className="tl-title">{l.text}</div>
                  <div className="tl-time">{l.time} · {l.user}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="section-title mb-4">Active RFQs</div>
          {data.rfqs.map(r=>(
            <div key={r.id} style={{padding:'10px 0', borderBottom:'1px solid var(--border)', display:'flex', justifyContent:'space-between', alignItems:'center'}}>
              <div>
                <div style={{fontWeight:500}}>{r.title}</div>
                <div className="text-muted text-sm mt-1">{r.id} · Due {fmtDate(r.deadline)}</div>
              </div>
              <span className={`badge badge-${r.status==='Open'?'blue':r.status==='Approved'?'green':r.status==='Comparison'?'gold':'gray'}`}>{r.status}</span>
            </div>
          ))}
        </div>
        <div className="card">
          <div className="section-title mb-4">Recent Purchase Orders</div>
          {data.orders.map(o=>(
            <div key={o.id} style={{padding:'10px 0', borderBottom:'1px solid var(--border)', display:'flex', justifyContent:'space-between', alignItems:'center'}}>
              <div>
                <div style={{fontWeight:500}}>{o.id}</div>
                <div className="text-muted text-sm mt-1">{o.title} · {fmtDate(o.createdAt)}</div>
              </div>
              <div style={{textAlign:'right'}}>
                <div style={{fontWeight:600, color:'var(--accent)'}}>{fmtCurrency(o.qty*o.unitPrice)}</div>
                <span className="badge badge-green text-sm">{o.status}</span>
              </div>
            </div>
          ))}
          {data.orders.length === 0 && <div className="text-muted">No purchase orders yet.</div>}
        </div>
      </div>
    </div>
  );
}

// ─── Vendor Management ─────────────────────────────────────────────────────
function VendorManagement({ data, setData, toast }) {
  const [search, setSearch] = useState('');
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ name:'', category:'IT Hardware', email:'', phone:'', gst:'', status:'Active' });

  const filtered = data.vendors.filter(v =>
    v.name.toLowerCase().includes(search.toLowerCase()) ||
    v.category.toLowerCase().includes(search.toLowerCase())
  );

  const addVendor = () => {
    const v = { ...form, id: genId('V', data.vendors), rating: 4.0 };
    setData(d => ({ ...d, vendors: [...d.vendors, v] }));
    setModal(false);
    setForm({ name:'', category:'IT Hardware', email:'', phone:'', gst:'', status:'Active' });
    toast('Vendor registered successfully');
  };

  const toggleStatus = (id) => {
    setData(d => ({ ...d, vendors: d.vendors.map(v => v.id===id ? {...v, status: v.status==='Active'?'Inactive':'Active'} : v) }));
  };

  const categories = ['IT Hardware','Office Supplies','Construction','Logistics','Facilities','Services'];

  return (
    <div>
      <div className="section-header">
        <div className="section-title">Vendor Registry</div>
        <div className="flex gap-2">
          <div className="search-box"><input placeholder="Search vendors…" value={search} onChange={e=>setSearch(e.target.value)} /></div>
          <button className="btn btn-primary" onClick={()=>setModal(true)}>+ Register Vendor</button>
        </div>
      </div>

      <div className="card-grid" style={{gridTemplateColumns:'repeat(auto-fill, minmax(260px,1fr))'}}>
        {filtered.map(v => (
          <div key={v.id} className="card" style={{position:'relative'}}>
            <div className="flex items-center gap-2 mb-2">
              <div style={{width:40,height:40,borderRadius:10,background:'var(--bg)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:18}}>🏢</div>
              <div>
                <div style={{fontWeight:600,fontSize:14}}>{v.name}</div>
                <div className="text-muted text-sm">{v.id}</div>
              </div>
              <span className={`badge badge-${v.status==='Active'?'green':'gray'}`} style={{marginLeft:'auto'}}>{v.status}</span>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:12}}>
              <div><div className="text-muted text-sm">Category</div><div style={{fontSize:12,fontWeight:500}}>{v.category}</div></div>
              <div><div className="text-muted text-sm">Rating</div><div style={{fontSize:12}}>{'⭐'.repeat(Math.floor(v.rating))} {v.rating}</div></div>
              <div><div className="text-muted text-sm">Email</div><div style={{fontSize:11,color:'var(--accent3)'}}>{v.email}</div></div>
              <div><div className="text-muted text-sm">GST</div><div style={{fontSize:11,fontFamily:'monospace'}}>{v.gst}</div></div>
            </div>
            <button className="btn btn-ghost btn-sm w-full" onClick={()=>toggleStatus(v.id)}>
              {v.status==='Active'?'Deactivate':'Activate'}
            </button>
          </div>
        ))}
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <div className="modal-title">Register New Vendor</div>
              <button className="close-btn" onClick={()=>setModal(false)}>×</button>
            </div>
            <div className="modal-body">
              <div className="form-grid">
                <div className="form-group full"><label>Company Name</label><input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} /></div>
                <div className="form-group"><label>Category</label><select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{categories.map(c=><option key={c}>{c}</option>)}</select></div>
                <div className="form-group"><label>Status</label><select value={form.status} onChange={e=>setForm({...form,status:e.target.value})}><option>Active</option><option>Inactive</option></select></div>
                <div className="form-group"><label>Email</label><input value={form.email} onChange={e=>setForm({...form,email:e.target.value})} /></div>
                <div className="form-group"><label>Phone</label><input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} /></div>
                <div className="form-group full"><label>GST Number</label><input value={form.gst} onChange={e=>setForm({...form,gst:e.target.value})} /></div>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-ghost" onClick={()=>setModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={addVendor}>Register Vendor</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── RFQ Management ────────────────────────────────────────────────────────
function RFQManagement({ data, setData, toast, setPage }) {
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ title:'', product:'', qty:1, deadline:'', vendorIds:[] });

  const addRFQ = () => {
    const rfq = { ...form, id: `RFQ-${String(data.rfqs.length+1).padStart(3,'0')}`, status:'Open', createdAt: new Date().toISOString().slice(0,10) };
    setData(d => ({
      ...d,
      rfqs: [...d.rfqs, rfq],
      logs: [...d.logs, { id: Date.now(), type:'rfq', text:`${rfq.id} created: ${rfq.title}`, time: new Date().toLocaleString(), user:'You' }]
    }));
    setModal(false);
    setForm({ title:'', product:'', qty:1, deadline:'', vendorIds:[] });
    toast('RFQ created successfully');
  };

  const toggleVendor = (id) => {
    setForm(f => ({ ...f, vendorIds: f.vendorIds.includes(id) ? f.vendorIds.filter(x=>x!==id) : [...f.vendorIds, id] }));
  };

  return (
    <div>
      <div className="section-header">
        <div className="section-title">Request for Quotations</div>
        <button className="btn btn-primary" onClick={()=>setModal(true)}>+ Create RFQ</button>
      </div>

      <div className="card table-wrap">
        <table>
          <thead>
            <tr>
              <th>RFQ ID</th><th>Title</th><th>Product / Service</th><th>Qty</th>
              <th>Deadline</th><th>Vendors</th><th>Status</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {data.rfqs.map(r=>(
              <tr key={r.id}>
                <td style={{fontFamily:'monospace',color:'var(--accent3)'}}>{r.id}</td>
                <td style={{fontWeight:500}}>{r.title}</td>
                <td className="text-muted">{r.product}</td>
                <td>{r.qty}</td>
                <td>{fmtDate(r.deadline)}</td>
                <td>{r.vendorIds.length} vendors</td>
                <td><span className={`badge badge-${r.status==='Open'?'blue':r.status==='Approved'?'green':r.status==='Comparison'?'gold':'gray'}`}>{r.status}</span></td>
                <td>
                  <div className="flex gap-2">
                    <button className="btn btn-secondary btn-sm" onClick={()=>setPage('quotations')}>View Quotes</button>
                    {r.status==='Comparison' && <button className="btn btn-ghost btn-sm" onClick={()=>setPage('compare')}>Compare</button>}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <div className="modal-title">Create New RFQ</div>
              <button className="close-btn" onClick={()=>setModal(false)}>×</button>
            </div>
            <div className="modal-body">
              <div className="form-grid">
                <div className="form-group full"><label>RFQ Title</label><input value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="e.g. Laptop Procurement Q4" /></div>
                <div className="form-group full"><label>Product / Service Details</label><input value={form.product} onChange={e=>setForm({...form,product:e.target.value})} placeholder="e.g. Dell Laptops 15-inch, Core i7" /></div>
                <div className="form-group"><label>Quantity</label><input type="number" min="1" value={form.qty} onChange={e=>setForm({...form,qty:+e.target.value})} /></div>
                <div className="form-group"><label>Submission Deadline</label><input type="date" value={form.deadline} onChange={e=>setForm({...form,deadline:e.target.value})} /></div>
                <div className="form-group full">
                  <label>Assign Vendors</label>
                  <div style={{display:'flex',flexWrap:'wrap',gap:8,marginTop:4}}>
                    {data.vendors.filter(v=>v.status==='Active').map(v=>(
                      <div key={v.id} onClick={()=>toggleVendor(v.id)}
                        style={{padding:'5px 12px',borderRadius:8,fontSize:12,cursor:'pointer',border:'1px solid',
                          borderColor: form.vendorIds.includes(v.id)?'var(--accent)':'var(--border)',
                          background: form.vendorIds.includes(v.id)?'rgba(79,255,176,.1)':'transparent',
                          color: form.vendorIds.includes(v.id)?'var(--accent)':'var(--muted)'}}>
                        {v.name}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-ghost" onClick={()=>setModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={addRFQ}>Create RFQ</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Quotations ────────────────────────────────────────────────────────────
function Quotations({ data, setData, toast }) {
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ rfqId:'', vendorId:'', unitPrice:'', delivery:'', notes:'' });

  const addQuote = () => {
    const q = { ...form, id: `Q${String(data.quotations.length+1).padStart(3,'0')}`, unitPrice: +form.unitPrice, status:'Submitted' };
    setData(d => ({
      ...d,
      quotations: [...d.quotations, q],
      rfqs: d.rfqs.map(r => r.id===form.rfqId && r.status==='Open' ? {...r, status:'Comparison'} : r),
      logs: [...d.logs, { id: Date.now(), type:'quotation', text:`Quotation submitted for ${form.rfqId}`, time: new Date().toLocaleString(), user:'Vendor' }]
    }));
    setModal(false);
    toast('Quotation submitted');
  };

  const getVendor = id => data.vendors.find(v=>v.id===id) || {};
  const getRFQ = id => data.rfqs.find(r=>r.id===id) || {};

  return (
    <div>
      <div className="section-header">
        <div className="section-title">Vendor Quotations</div>
        <button className="btn btn-primary" onClick={()=>setModal(true)}>+ Submit Quotation</button>
      </div>

      <div className="card table-wrap">
        <table>
          <thead>
            <tr><th>Quote ID</th><th>RFQ</th><th>Vendor</th><th>Unit Price</th><th>Delivery</th><th>Notes</th><th>Status</th></tr>
          </thead>
          <tbody>
            {data.quotations.map(q=>(
              <tr key={q.id}>
                <td style={{fontFamily:'monospace',color:'var(--accent3)'}}>{q.id}</td>
                <td>{q.rfqId}</td>
                <td>{getVendor(q.vendorId).name}</td>
                <td style={{color:'var(--accent)',fontWeight:600}}>{fmtCurrency(q.unitPrice)}</td>
                <td>{q.delivery}</td>
                <td className="text-muted" style={{maxWidth:180,fontSize:12}}>{q.notes}</td>
                <td><span className={`badge badge-${q.status==='Approved'?'green':q.status==='Rejected'?'red':'blue'}`}>{q.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setModal(false)}>
          <div className="modal">
            <div className="modal-header">
              <div className="modal-title">Submit Quotation</div>
              <button className="close-btn" onClick={()=>setModal(false)}>×</button>
            </div>
            <div className="modal-body">
              <div className="form-grid">
                <div className="form-group"><label>RFQ</label>
                  <select value={form.rfqId} onChange={e=>setForm({...form,rfqId:e.target.value})}>
                    <option value="">Select RFQ</option>
                    {data.rfqs.filter(r=>r.status==='Open'||r.status==='Comparison').map(r=><option key={r.id} value={r.id}>{r.id} – {r.title}</option>)}
                  </select>
                </div>
                <div className="form-group"><label>Vendor</label>
                  <select value={form.vendorId} onChange={e=>setForm({...form,vendorId:e.target.value})}>
                    <option value="">Select Vendor</option>
                    {data.vendors.filter(v=>v.status==='Active').map(v=><option key={v.id} value={v.id}>{v.name}</option>)}
                  </select>
                </div>
                <div className="form-group"><label>Unit Price (₹)</label><input type="number" value={form.unitPrice} onChange={e=>setForm({...form,unitPrice:e.target.value})} /></div>
                <div className="form-group"><label>Delivery Timeline</label><input value={form.delivery} onChange={e=>setForm({...form,delivery:e.target.value})} placeholder="e.g. 10 days" /></div>
                <div className="form-group full"><label>Notes / Comments</label><textarea value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} /></div>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-ghost" onClick={()=>setModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={addQuote}>Submit Quotation</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Comparison ────────────────────────────────────────────────────────────
function Comparison({ data, setData, toast, setPage }) {
  const [selRFQ, setSelRFQ] = useState(data.rfqs.find(r=>r.status==='Comparison')?.id || data.rfqs[0]?.id || '');

  const rfq = data.rfqs.find(r=>r.id===selRFQ);
  const quotes = data.quotations.filter(q=>q.rfqId===selRFQ);
  const getVendor = id => data.vendors.find(v=>v.id===id) || {};
  const minPrice = quotes.length ? Math.min(...quotes.map(q=>q.unitPrice)) : 0;

  const selectQuote = (q) => {
    setData(d => ({
      ...d,
      approvals: [...d.approvals, { id:`APR-${String(d.approvals.length+1).padStart(3,'0')}`, rfqId:selRFQ, quotationId:q.id, requestedBy:'You', status:'Pending', remarks:'', createdAt:new Date().toISOString().slice(0,10), resolvedAt:null }],
      rfqs: d.rfqs.map(r=>r.id===selRFQ?{...r,status:'Pending Approval'}:r),
      logs: [...d.logs, { id:Date.now(), type:'approval', text:`Approval requested for ${q.id} (${selRFQ})`, time:new Date().toLocaleString(), user:'You' }]
    }));
    toast('Approval request submitted');
    setPage('approvals');
  };

  return (
    <div>
      <div className="section-header">
        <div className="section-title">Quotation Comparison</div>
        <select value={selRFQ} onChange={e=>setSelRFQ(e.target.value)} style={{width:260}}>
          {data.rfqs.map(r=><option key={r.id} value={r.id}>{r.id} – {r.title}</option>)}
        </select>
      </div>

      {quotes.length === 0 ? (
        <div className="card text-muted" style={{padding:40, textAlign:'center'}}>No quotations received for this RFQ yet.</div>
      ) : (
        <div className="card table-wrap">
          <table className="compare-table">
            <thead>
              <tr>
                <th>Criteria</th>
                {quotes.map(q=>(
                  <th key={q.id} style={{textAlign:'center'}}>
                    <div>{getVendor(q.vendorId).name}</div>
                    <div style={{fontSize:10,color:'var(--muted)',fontWeight:400}}>{q.id}</div>
                    <div style={{marginTop:4}}>{'⭐'.repeat(Math.floor(getVendor(q.vendorId).rating||4))}</div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style={{fontWeight:500}}>Unit Price</td>
                {quotes.map(q=>(
                  <td key={q.id} style={{textAlign:'center'}} className={q.unitPrice===minPrice?'best-price':''}>
                    {fmtCurrency(q.unitPrice)} {q.unitPrice===minPrice&&<span title="Lowest">🏆</span>}
                  </td>
                ))}
              </tr>
              <tr>
                <td style={{fontWeight:500}}>Total (×{rfq?.qty||1})</td>
                {quotes.map(q=><td key={q.id} style={{textAlign:'center',fontWeight:600}}>{fmtCurrency(q.unitPrice*(rfq?.qty||1))}</td>)}
              </tr>
              <tr>
                <td style={{fontWeight:500}}>Delivery Timeline</td>
                {quotes.map(q=><td key={q.id} style={{textAlign:'center'}}>{q.delivery}</td>)}
              </tr>
              <tr>
                <td style={{fontWeight:500}}>Notes</td>
                {quotes.map(q=><td key={q.id} style={{textAlign:'center',fontSize:12,color:'var(--muted)'}}>{q.notes}</td>)}
              </tr>
              <tr>
                <td style={{fontWeight:500}}>Action</td>
                {quotes.map(q=>(
                  <td key={q.id} style={{textAlign:'center'}}>
                    <button className="btn btn-primary btn-sm" onClick={()=>selectQuote(q)}>Select & Approve</button>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ─── Approvals ─────────────────────────────────────────────────────────────
function Approvals({ data, setData, toast, setPage }) {
  const [remarks, setRemarks] = useState({});

  const resolve = (apr, action) => {
    const qId = apr.quotationId;
    const rfq = data.rfqs.find(r=>r.id===apr.rfqId);
    if (action==='Approved') {
      const q = data.quotations.find(q=>q.id===qId);
      const poId = `PO-2026-${String(data.orders.length+1).padStart(3,'0')}`;
      const newPO = { id:poId, rfqId:apr.rfqId, quotationId:qId, vendorId:q.vendorId, title:rfq?.title||'Purchase Order', qty:rfq?.qty||1, unitPrice:q.unitPrice, tax:18, status:'Active', createdAt:new Date().toISOString().slice(0,10), invoiceId:null };
      setData(d=>({
        ...d,
        approvals: d.approvals.map(a=>a.id===apr.id?{...a,status:'Approved',remarks:remarks[apr.id]||'',resolvedAt:new Date().toISOString().slice(0,10)}:a),
        quotations: d.quotations.map(q=>q.id===qId?{...q,status:'Approved'}:q),
        rfqs: d.rfqs.map(r=>r.id===apr.rfqId?{...r,status:'Approved'}:r),
        orders: [...d.orders, newPO],
        logs: [...d.logs,{id:Date.now(),type:'approval',text:`${apr.id} approved → ${poId} created`,time:new Date().toLocaleString(),user:'You'}]
      }));
      toast('Approved! Purchase Order generated');
      setTimeout(()=>setPage('orders'), 400);
    } else {
      setData(d=>({
        ...d,
        approvals: d.approvals.map(a=>a.id===apr.id?{...a,status:'Rejected',remarks:remarks[apr.id]||'',resolvedAt:new Date().toISOString().slice(0,10)}:a),
        rfqs: d.rfqs.map(r=>r.id===apr.rfqId?{...r,status:'Open'}:r),
      }));
      toast('Quotation rejected');
    }
  };

  return (
    <div>
      <div className="section-header">
        <div className="section-title">Approval Workflow</div>
      </div>

      <div style={{display:'flex',flexDirection:'column',gap:14}}>
        {data.approvals.map(apr=>{
          const rfq = data.rfqs.find(r=>r.id===apr.rfqId);
          const q = data.quotations.find(q=>q.id===apr.quotationId);
          const vendor = data.vendors.find(v=>v.id===q?.vendorId);
          return (
            <div key={apr.id} className="card">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <div style={{fontWeight:600,fontSize:15}}>{rfq?.title || apr.rfqId}</div>
                  <div className="text-muted text-sm mt-1">{apr.id} · Requested by {apr.requestedBy} on {fmtDate(apr.createdAt)}</div>
                </div>
                <span className={`badge badge-${apr.status==='Approved'?'green':apr.status==='Rejected'?'red':'gold'}`}>{apr.status}</span>
              </div>
              <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:10,margin:'14px 0',padding:'12px 0',borderTop:'1px solid var(--border)',borderBottom:'1px solid var(--border)'}}>
                <div><div className="text-muted text-sm">Quotation</div><div style={{fontWeight:500}}>{apr.quotationId}</div></div>
                <div><div className="text-muted text-sm">Vendor</div><div style={{fontWeight:500}}>{vendor?.name||'—'}</div></div>
                <div><div className="text-muted text-sm">Amount</div><div style={{fontWeight:600,color:'var(--accent)'}}>{q?fmtCurrency(q.unitPrice*(rfq?.qty||1)):'—'}</div></div>
              </div>
              {apr.status==='Pending' && (
                <div style={{display:'flex',flexDirection:'column',gap:10}}>
                  <div className="form-group">
                    <label>Approval Remarks</label>
                    <input value={remarks[apr.id]||''} onChange={e=>setRemarks(r=>({...r,[apr.id]:e.target.value}))} placeholder="Add remarks…" />
                  </div>
                  <div className="flex gap-2">
                    <button className="btn btn-primary" onClick={()=>resolve(apr,'Approved')}>✓ Approve</button>
                    <button className="btn btn-danger" onClick={()=>resolve(apr,'Rejected')}>✗ Reject</button>
                  </div>
                </div>
              )}
              {apr.status!=='Pending' && apr.remarks && (
                <div style={{fontSize:13,color:'var(--muted)',fontStyle:'italic'}}>Remarks: {apr.remarks}</div>
              )}
            </div>
          );
        })}
        {data.approvals.length===0 && <div className="card text-muted" style={{padding:40,textAlign:'center'}}>No approval requests yet.</div>}
      </div>
    </div>
  );
}

// ─── Purchase Orders ───────────────────────────────────────────────────────
function PurchaseOrders({ data, setData, toast, setPage }) {
  const [invModal, setInvModal] = useState(null);

  const generateInvoice = (po) => {
    const invId = `INV-2026-${String(data.invoices.length+1).padStart(3,'0')}`;
    const inv = { id:invId, poId:po.id, vendorId:po.vendorId, title:po.title, qty:po.qty, unitPrice:po.unitPrice, tax:po.tax, status:'Generated', createdAt:new Date().toISOString().slice(0,10) };
    setData(d=>({
      ...d,
      invoices: [...d.invoices, inv],
      orders: d.orders.map(o=>o.id===po.id?{...o,status:'Invoiced',invoiceId:invId}:o),
      logs: [...d.logs,{id:Date.now(),type:'invoice',text:`${invId} generated from ${po.id}`,time:new Date().toLocaleString(),user:'You'}]
    }));
    toast('Invoice generated');
    setInvModal(null);
    setPage('invoices');
  };

  const getVendor = id => data.vendors.find(v=>v.id===id)||{};

  return (
    <div>
      <div className="section-header">
        <div className="section-title">Purchase Orders</div>
      </div>

      <div style={{display:'flex',flexDirection:'column',gap:14}}>
        {data.orders.map(po=>{
          const sub = po.qty * po.unitPrice;
          const tax = sub * po.tax / 100;
          const total = sub + tax;
          const vendor = getVendor(po.vendorId);
          return (
            <div key={po.id} className="card">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div style={{fontFamily:'var(--font-head)',fontSize:16,fontWeight:700}}>{po.id}</div>
                  <div className="text-muted text-sm mt-1">{po.title} · {fmtDate(po.createdAt)}</div>
                </div>
                <span className={`badge badge-${po.status==='Invoiced'?'green':'blue'}`}>{po.status}</span>
              </div>
              <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10,padding:'12px 0',borderTop:'1px solid var(--border)',borderBottom:'1px solid var(--border)',marginBottom:14}}>
                <div><div className="text-muted text-sm">Vendor</div><div style={{fontWeight:500}}>{vendor.name}</div></div>
                <div><div className="text-muted text-sm">Qty × Unit</div><div style={{fontWeight:500}}>{po.qty} × {fmtCurrency(po.unitPrice)}</div></div>
                <div><div className="text-muted text-sm">Tax ({po.tax}%)</div><div style={{fontWeight:500}}>{fmtCurrency(tax)}</div></div>
                <div><div className="text-muted text-sm">Grand Total</div><div style={{fontWeight:700,color:'var(--accent)',fontSize:16}}>{fmtCurrency(total)}</div></div>
              </div>
              <div className="flex gap-2">
                {po.status!=='Invoiced' && <button className="btn btn-primary btn-sm" onClick={()=>generateInvoice(po)}>Generate Invoice</button>}
                {po.status==='Invoiced' && <button className="btn btn-secondary btn-sm" onClick={()=>setPage('invoices')}>View Invoice →</button>}
              </div>
            </div>
          );
        })}
        {data.orders.length===0 && <div className="card text-muted" style={{padding:40,textAlign:'center'}}>No purchase orders yet. Approve a quotation to create one.</div>}
      </div>
    </div>
  );
}

// ─── Invoices ──────────────────────────────────────────────────────────────
function Invoices({ data, setData, toast }) {
  const [viewing, setViewing] = useState(null);
  const getVendor = id => data.vendors.find(v=>v.id===id)||{};

  const markSent = (inv) => {
    setData(d=>({ ...d, invoices: d.invoices.map(i=>i.id===inv.id?{...i,status:'Sent'}:i) }));
    toast(`Invoice ${inv.id} sent via email`);
  };

  const InvoiceView = ({ inv }) => {
    const sub = inv.qty * inv.unitPrice;
    const taxAmt = sub * inv.tax / 100;
    const total = sub + taxAmt;
    const vendor = getVendor(inv.vendorId);
    return (
      <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setViewing(null)}>
        <div className="modal" style={{maxWidth:640}}>
          <div className="modal-header">
            <div className="modal-title">Invoice — {inv.id}</div>
            <button className="close-btn" onClick={()=>setViewing(null)}>×</button>
          </div>
          <div className="modal-body">
            <div style={{background:'var(--bg)',borderRadius:10,padding:20,fontFamily:'monospace',fontSize:12,lineHeight:1.8}}>
              <div style={{display:'flex',justifyContent:'space-between',marginBottom:16}}>
                <div>
                  <div style={{fontFamily:'var(--font-head)',fontSize:22,fontWeight:800,color:'var(--accent)'}}>VendorBridge</div>
                  <div style={{color:'var(--muted)',fontSize:11}}>Procurement ERP · GST: 27AAVB0001K1ZX</div>
                </div>
                <div style={{textAlign:'right'}}>
                  <div style={{fontWeight:700,fontSize:16}}>{inv.id}</div>
                  <div style={{color:'var(--muted)'}}>Date: {fmtDate(inv.createdAt)}</div>
                </div>
              </div>
              <div style={{padding:'10px 0',borderTop:'1px solid var(--border)',borderBottom:'1px solid var(--border)',marginBottom:14}}>
                <div style={{fontWeight:600,marginBottom:4}}>Bill To:</div>
                <div>{vendor.name}</div>
                <div style={{color:'var(--muted)'}}>{vendor.email} · GST: {vendor.gst}</div>
              </div>
              <table style={{width:'100%',borderCollapse:'collapse',marginBottom:14}}>
                <thead><tr style={{borderBottom:'1px solid var(--border)'}}>
                  <th style={{padding:'6px 0',textAlign:'left'}}>Description</th>
                  <th style={{padding:'6px 0',textAlign:'right'}}>Qty</th>
                  <th style={{padding:'6px 0',textAlign:'right'}}>Unit</th>
                  <th style={{padding:'6px 0',textAlign:'right'}}>Amount</th>
                </tr></thead>
                <tbody><tr>
                  <td style={{padding:'6px 0'}}>{inv.title}</td>
                  <td style={{padding:'6px 0',textAlign:'right'}}>{inv.qty}</td>
                  <td style={{padding:'6px 0',textAlign:'right'}}>{fmtCurrency(inv.unitPrice)}</td>
                  <td style={{padding:'6px 0',textAlign:'right'}}>{fmtCurrency(sub)}</td>
                </tr></tbody>
              </table>
              <div style={{textAlign:'right'}}>
                <div>Subtotal: {fmtCurrency(sub)}</div>
                <div>IGST ({inv.tax}%): {fmtCurrency(taxAmt)}</div>
                <div style={{fontWeight:700,fontSize:15,color:'var(--accent)',marginTop:4}}>Total: {fmtCurrency(total)}</div>
              </div>
              <div style={{marginTop:16,color:'var(--muted)',fontSize:11}}>Terms: Payment due within 30 days. All disputes subject to Mumbai jurisdiction.</div>
            </div>
          </div>
          <div className="modal-footer">
            <button className="btn btn-ghost" onClick={()=>window.print()}>🖨 Print</button>
            <button className="btn btn-secondary" onClick={()=>markSent(inv)}>📧 Send via Email</button>
            <button className="btn btn-primary" onClick={()=>setViewing(null)}>Close</button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div>
      <div className="section-header">
        <div className="section-title">Invoices</div>
      </div>

      <div style={{display:'flex',flexDirection:'column',gap:14}}>
        {data.invoices.map(inv=>{
          const sub = inv.qty * inv.unitPrice;
          const taxAmt = sub * inv.tax / 100;
          const total = sub + taxAmt;
          const vendor = getVendor(inv.vendorId);
          return (
            <div key={inv.id} className="card">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div style={{fontFamily:'var(--font-head)',fontSize:15,fontWeight:700}}>{inv.id}</div>
                  <div className="text-muted text-sm mt-1">{vendor.name} · {fmtDate(inv.createdAt)}</div>
                </div>
                <span className={`badge badge-${inv.status==='Sent'?'green':inv.status==='Paid'?'green':'gold'}`}>{inv.status}</span>
              </div>
              <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10,padding:'12px 0',borderTop:'1px solid var(--border)',borderBottom:'1px solid var(--border)',marginBottom:14}}>
                <div><div className="text-muted text-sm">Description</div><div style={{fontWeight:500,fontSize:12}}>{inv.title}</div></div>
                <div><div className="text-muted text-sm">Subtotal</div><div style={{fontWeight:500}}>{fmtCurrency(sub)}</div></div>
                <div><div className="text-muted text-sm">Tax</div><div style={{fontWeight:500}}>{fmtCurrency(taxAmt)}</div></div>
                <div><div className="text-muted text-sm">Total</div><div style={{fontWeight:700,color:'var(--accent)',fontSize:16}}>{fmtCurrency(total)}</div></div>
              </div>
              <div className="flex gap-2">
                <button className="btn btn-secondary btn-sm" onClick={()=>setViewing(inv)}>👁 View Invoice</button>
                <button className="btn btn-ghost btn-sm" onClick={()=>window.print()}>🖨 Print</button>
                {inv.status!=='Sent' && <button className="btn btn-primary btn-sm" onClick={()=>markSent(inv)}>📧 Send Email</button>}
              </div>
            </div>
          );
        })}
        {data.invoices.length===0 && <div className="card text-muted" style={{padding:40,textAlign:'center'}}>No invoices yet. Generate one from a Purchase Order.</div>}
      </div>

      {viewing && <InvoiceView inv={viewing} />}
    </div>
  );
}

// ─── Activity Logs ─────────────────────────────────────────────────────────
function ActivityLogs({ data }) {
  const typeIcon = { rfq:'📋', quotation:'📝', approval:'✅', invoice:'🧾', order:'📦' };
  const typeBadge = { rfq:'blue', quotation:'gold', approval:'green', invoice:'red' };
  return (
    <div>
      <div className="section-header"><div className="section-title">Activity Logs & Notifications</div></div>
      <div className="card">
        <div className="timeline">
          {[...data.logs].reverse().map(l=>(
            <div key={l.id} className="tl-item">
              <div className="tl-dot" style={{background:`var(--${typeBadge[l.type]||'accent'})`}} />
              <div className="tl-content">
                <div style={{display:'flex',alignItems:'center',gap:8}}>
                  <span>{typeIcon[l.type]||'📌'}</span>
                  <div className="tl-title">{l.text}</div>
                  <span className={`badge badge-${typeBadge[l.type]||'gray'} text-sm`}>{l.type}</span>
                </div>
                <div className="tl-time">{l.time} · {l.user}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Reports ───────────────────────────────────────────────────────────────
function Reports({ data }) {
  const totalSpend = data.invoices.reduce((s,i)=>{ const sub=i.qty*i.unitPrice; return s+sub+sub*i.tax/100; },0);
  const avgRating = data.vendors.length ? (data.vendors.reduce((s,v)=>s+v.rating,0)/data.vendors.length).toFixed(1) : 0;
  const months = ['Jan','Feb','Mar','Apr','May','Jun'];
  const spends = [420000,680000,510000,790000,630000, data.invoices.reduce((s,i)=>{ const sub=i.qty*i.unitPrice; return s+sub+sub*i.tax/100; },0)];
  const maxS = Math.max(...spends);

  return (
    <div>
      <div className="section-header"><div className="section-title">Reports & Analytics</div>
        <button className="btn btn-secondary btn-sm">⬇ Export CSV</button>
      </div>

      <div className="card-grid" style={{marginBottom:20}}>
        {[
          {label:'Total Vendors',value:data.vendors.length,icon:'🏢',cls:'blue'},
          {label:'Total RFQs',value:data.rfqs.length,icon:'📋',cls:'green'},
          {label:'Total Invoiced',value:fmtCurrency(totalSpend),icon:'💰',cls:'gold'},
          {label:'Avg Vendor Rating',value:`${avgRating} ⭐`,icon:'⭐',cls:'red'},
        ].map(s=>(
          <div key={s.label} className={`stat-card ${s.cls}`}>
            <div className="stat-icon">{s.icon}</div>
            <div className="stat-label">{s.label}</div>
            <div className="stat-value" style={{fontSize:typeof s.value==='string'?'18px':'30px'}}>{s.value}</div>
          </div>
        ))}
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="section-title mb-4">Monthly Spend Trend</div>
          <div className="chart-bars">
            {months.map((m,i)=>(
              <div key={m} className="chart-bar-wrap">
                <div className="chart-bar" style={{height:`${(spends[i]/maxS)*100}%`,background:i===5?'var(--accent)':'var(--accent3)'}} />
                <div className="chart-label">{m}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="card">
          <div className="section-title mb-4">Vendor Performance</div>
          {data.vendors.map(v=>(
            <div key={v.id} style={{marginBottom:14}}>
              <div className="flex items-center justify-between mb-1">
                <span style={{fontSize:13}}>{v.name}</span>
                <span style={{fontSize:12,color:'var(--accent)'}}>{v.rating}/5</span>
              </div>
              <div className="progress-bar">
                <div className="progress-fill" style={{width:`${(v.rating/5)*100}%`}} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Main App ──────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState('dashboard');
  const [data, setData] = useState(INIT);
  const [toastMsg, setToastMsg] = useState(null);

  const toast = (msg) => { setToastMsg(msg); };

  const navItems = [
    { id:'dashboard', label:'Dashboard', icon:'⊞', section:'Main' },
    { id:'vendors', label:'Vendors', icon:'🏢', section:'Procurement' },
    { id:'rfqs', label:'RFQs', icon:'📋', section:'Procurement' },
    { id:'quotations', label:'Quotations', icon:'📝', section:'Procurement' },
    { id:'compare', label:'Compare', icon:'⚖', section:'Procurement' },
    { id:'approvals', label:'Approvals', icon:'✅', section:'Workflow', badge: data.approvals.filter(a=>a.status==='Pending').length||null },
    { id:'orders', label:'Purchase Orders', icon:'📦', section:'Documents' },
    { id:'invoices', label:'Invoices', icon:'🧾', section:'Documents' },
    { id:'logs', label:'Activity Logs', icon:'📜', section:'Monitoring' },
    { id:'reports', label:'Reports', icon:'📊', section:'Monitoring' },
  ];

  const sections = [...new Set(navItems.map(n=>n.section))];
  const pageTitle = navItems.find(n=>n.id===page)?.label || 'Dashboard';

  if (!user) return <><GlobalStyle /><LoginScreen onLogin={u=>{setUser(u);}} /></>;

  return (
    <>
      <GlobalStyle />
      <div className="app">
        <aside className="sidebar">
          <div className="logo">Vendor<span>Bridge</span><sub>Procurement ERP</sub></div>
          {sections.map(sec=>(
            <div key={sec}>
              <div className="nav-section">{sec}</div>
              {navItems.filter(n=>n.section===sec).map(n=>(
                <div key={n.id} className={`nav-item ${page===n.id?'active':''}`} onClick={()=>setPage(n.id)}>
                  <span className="icon">{n.icon}</span>
                  {n.label}
                  {n.badge ? <span className="nav-badge">{n.badge}</span> : null}
                </div>
              ))}
            </div>
          ))}
          <div className="sidebar-footer">
            <div className="user-chip">
              <div className="avatar">{user.role[0]}</div>
              <div className="user-info">
                <b>{user.email.split('@')[0]}</b>
                <div className="user-role">{user.role}</div>
              </div>
              <span style={{marginLeft:'auto',cursor:'pointer',color:'var(--muted)',fontSize:13}} onClick={()=>setUser(null)} title="Logout">⏏</span>
            </div>
          </div>
        </aside>

        <div className="main">
          <div className="topbar">
            <div className="page-title">{pageTitle}</div>
            <div className="topbar-right">
              <button className="notif-btn">🔔<div className="notif-dot"/></button>
              <div className="search-box" style={{display:'flex',alignItems:'center'}}>
                <input placeholder="Search…" style={{width:180}} />
              </div>
            </div>
          </div>

          <div className="content">
            {page==='dashboard'   && <Dashboard data={data} />}
            {page==='vendors'     && <VendorManagement data={data} setData={setData} toast={toast} />}
            {page==='rfqs'        && <RFQManagement data={data} setData={setData} toast={toast} setPage={setPage} />}
            {page==='quotations'  && <Quotations data={data} setData={setData} toast={toast} />}
            {page==='compare'     && <Comparison data={data} setData={setData} toast={toast} setPage={setPage} />}
            {page==='approvals'   && <Approvals data={data} setData={setData} toast={toast} setPage={setPage} />}
            {page==='orders'      && <PurchaseOrders data={data} setData={setData} toast={toast} setPage={setPage} />}
            {page==='invoices'    && <Invoices data={data} setData={setData} toast={toast} />}
            {page==='logs'        && <ActivityLogs data={data} />}
            {page==='reports'     && <Reports data={data} />}
          </div>
        </div>
      </div>
      {toastMsg && <Toast msg={toastMsg} onDone={()=>setToastMsg(null)} />}
    </>
  );
}
