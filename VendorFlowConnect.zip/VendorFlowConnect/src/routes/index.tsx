import { createFileRoute } from "@tanstack/react-router";
// @ts-expect-error - JSX component without types
import VendorBridge from "@/components/VendorBridge.jsx";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "VendorBridge — Procurement & Vendor Management ERP" },
      { name: "description", content: "Centralized ERP to digitize end-to-end procurement, RFQs, approvals, and vendor management." },
      { property: "og:title", content: "VendorBridge — Procurement & Vendor Management ERP" },
      { property: "og:description", content: "Centralized ERP to digitize end-to-end procurement, RFQs, approvals, and vendor management." },
    ],
  }),
  component: Index,
});

function Index() {
  return <VendorBridge />;
}
